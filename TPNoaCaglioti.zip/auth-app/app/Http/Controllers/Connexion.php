<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Utilisateur;
use App\Models\Log;
use App\Models\Reactivation;
use App\Http\Controllers\Email;

/* A FAIRE (fiche 3, partie 2, question 1) : inclure ci-dessous le use PHP pour la libriairie gérant l'A2F */

// A FAIRE (fiche 3, partie 3, question 4) : inclure ci-dessous le use PHP pour la libriairie gérant le JWT

class Connexion extends Controller
{
    public function afficherFormulaireConnexion() {
        return view('formulaireConnexion', []);
    }

    public function afficherFormulaireVerificationA2F() {
        if(session()->has('connexion')) {
            if(Utilisateur::where("idUtilisateur", session()->get('connexion'))->count() > 0) {
                return view('formulaireA2F', []);
            }
            else {
                session()->forget('connexion');
                return view('formulaireConnexion', []);
            }
        }
        else {
            return view('formulaireConnexion', []);
        }
    }

    public function reactivationCompte() {
        $validation = false; // Booléen vrai/faux si les conditions de vérification sont remplies pour réactiver le compte
        $messageAAfficher = null; // Contient le message d'erreur ou de succès à afficher

        /* A FAIRE (fiche 3, partie 1, question 4) : vérification du code dans l'URL ainsi que de l'expiration du lien + réactivation du compte */

        if($validation === false) {
            return view("pageErreur", ["messageErreur" => $messageAAfficher]);
        }
        else {
            return view('confirmationReactivation', ["messageConfirmation" => $messageAAfficher]);
        }
    }

    public function boutonVerificationCodeA2F() {
        $validationFormulaire = false; // Booléen qui indique si les données du formulaire sont valides
        $messagesErreur = array(); // Tableau contenant les messages d'erreur à afficher

        /* A FAIRE (fiche 3, partie 2, question 1) : vérification du code A2F */

        /* A FAIRE (fiche 3, partie 3, question 4) : générer un JWT une fois le code A2F validé + création du cookie + redirection vers la page de profil */

        // Redirection vers la page du profil :
        //return redirect()->to('profil')->send();
    }
    
    public function boutonConnexion() {
        $validationFormulaire = false; // Booléen qui indique si les données du formulaire sont valides
        $messagesErreur = array(); // Tableau contenant les messages d'erreur à afficher

        /* A FAIRE (fiche 3, partie 1, question 3) : vérification du couple login/mot de passe */
        $email = $_POST["email"];
        $motDePasse = $_POST["motdepasse"];

        if(!(new Utilisateur)->existeEmail($email)) {
            $messagesErreur[] = "Email introuvable";
        } else {
            $infos = (new Utilisateur)->getInfosUtilisateur($email);
            if((new Utilisateur)->estDesactive($email)) {
                $messagesErreur[] = "Compte désactivé";
            } else {
                if(password_verify($motDePasse, $infos->motDePasseUtilisateur)) {
                    $_SESSION["connexion"] = 1;
                    Log::ecrireLog($_POST["email"], "Connexion aboutie");
                    (new Utilisateur)->reinitialiserTentatives();
                    return view('formulaireA2F', ["messagesErreur" => $messagesErreur]);
                } else {
                    (new Utilisateur)->ajouterTentative();
                    Log::ecrireLog($_POST["email"], "Tentative de connexion échouée");
                    if((new Utilisateur)->getNbTentatives() > 5) {
                        (new Utilisateur)->desactiverCompte();
                        $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                        $code = '';
                        for($i=0; $i<8; $i++){
                            $code .= $chars[rand(0, strlen($chars)-1)];
                        }
                        (new Email)->envoyerEmail($email, "Compte désactivé", "Votre compte a été désactivé car vous avez fait trop de tentatives échouées. Cliquez sur ce lien pour le réactiver : http://172.17.0.17/reactivation?code=".$code);
                    }
                    $messagesErreur[] = "Mot de passe incorrect";
                    return view('formulaireConnexion', ["messagesErreur" => $messagesErreur]);
                }
            }
        }
        

        if($validationFormulaire === false) {
            return view('formulaireConnexion', ["messagesErreur" => $messagesErreur]);
        }
        else {
            return view('formulaireA2F', []);
        }
    }

    public function deconnexion() {
        if(session()->has('connexion')) {
            session()->forget('connexion');
        }
        if(isset($_COOKIE["auth"])) {
            setcookie("auth", "", time()-3600);
        }

        return redirect()->to('connexion')->send();
    }

    public function validationFormulaire() {
        if(isset($_POST["boutonVerificationCodeA2F"])) {
            return $this->boutonVerificationCodeA2F();
        }
        else {
            if(isset($_POST["boutonConnexion"])) {
                return $this->boutonConnexion();
            }
            else {
                return redirect()->to('connexion')->send();
            }
        }
    }
}