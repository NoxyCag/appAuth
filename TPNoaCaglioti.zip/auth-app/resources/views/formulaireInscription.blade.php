<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" data-bs-theme="dark">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Inscription</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    </head>
    <body class="align-items-center w-100">
        @include('menuPrincipal')

        <main class="align-items-center w-100">
            <form method="POST" action="{{ route('validationFormulaireInscription') }}" class="card w-50 mx-auto mt-5 mb-5">
                @csrf
                <div class="card-body align-items-center text-center">
                    <h1 class="mb-3 card-title">
                        Inscription
                    </h1>
                    @include('messageErreur')
                    <div>
                        <div class="mb-3">
                            <i>Tous les champs sont obligatoires</i>
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" placeholder="Nom" name="nom" required>
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" placeholder="Prenom" name="prenom" required>
                        </div>
                        <div class="mb-3">
                            <input type="email" class="form-control" placeholder="Email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <input type="password" class="form-control" placeholder="Mot de passe" name="motDePasse1" required>
                        </div>
                        <div class="mb-3">
                            <input type="password" class="form-control" placeholder="Mot de passe" name="motDePasse2" required>
                        </div>
                        
                        <div class="card mb-3 text-start">
                            <div class="card-body">
                                <h5 class="card-title">Conditions d'utilisation des données à caractère personnel :</h5>
                                <p><strong>Protection de vos données personnelles :</strong></p>
                                <p>Les informations collectées via ce formulaire sont nécessaires pour la création et la gestion de votre compte.

                                Au moins 12 caractères
                                Lettres majuscules
                                Lettres minuscules 
                                Chiffre
                                Caractères spéciaux


                                </p>
                                <ul>
                                    <li><strong>Finalités :</strong> Création de votre compte utilisateur, gestion des communications nécessaires, et envoi éventuel de newsletters (avec votre consentement).</li>
                                    <li><strong>Base légale :</strong> Consentement et exécution du contrat (création de votre compte).</li>
                                    <li><strong>Durée de conservation :</strong> Vos données seront conservées tant que votre compte est actif, ou conformément aux obligations légales.</li>
                                </ul>
                                <p><strong>Vos droits :</strong> Vous pouvez à tout moment :</p>
                                <ul>
                                    <li>Accéder à vos données personnelles et les rectifier si elles sont inexactes.</li>
                                    <li>Demander leur suppression ou limiter leur traitement.</li>
                                    <li>Vous opposer à leur traitement ou retirer votre consentement.</li>
                                    <li>Porter plainte auprès de l’autorité compétente (CNIL en France).</li>
                                </ul>
                                <p><em>En cliquant sur "S'inscrire", vous acceptez ces conditions.</em></p>
                            </div>
                        </div>
                        <div class="input-group mb-3 form-check">
                            <input class="form-check-input me-3" type="checkbox" required id="acceptation">
                            <label class="form-check-label" for="acceptation">
                                J'accepte les conditions d'utilisation de mes données à caractère personnel
                            </label>                          
                        </div>
                    </div>
                    <div class="input-group d-grid gap-2">
                        <button class="btn btn-primary btn-lg" type="submit" name="boutonInscription">Valider</button>
                    </div>
                </div>
            </form>
        </main>
    </body>
</html>